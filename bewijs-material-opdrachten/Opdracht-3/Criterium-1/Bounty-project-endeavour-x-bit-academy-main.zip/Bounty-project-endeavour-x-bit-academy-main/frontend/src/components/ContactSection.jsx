function ContactSection() {
    return(
        <>
            <div className="flex justify-center mt-20 text-center mb-10 ">
                <div className="w-full h-[500px] border border-[#1f2937]/20 rounded-lg flex justify-center items-start align-middle shadow-md p-4 max-w-7xl sm:pl-4 lg:px-8 mx-4">
                    <div className="flex flex-col h-[70%] items-center mt-4">
                        <h2 className="md:text-3xl text-xl font-bold mb-10 mt-2 ">Zelf een voorstel voor events?</h2>
                        <p className="md:text-xl text-base ">Heb jij een vet idee voor een volgende Endeavour event? Laat het ons weten!</p>
                        <hr className="border-[#1f2937]/20  md:w-full w-[60%] mt-4" />
                        <form action="#" className="flex flex-col w-[60%] mt-10">
                            <div className="flex flex-col ">
                                <label htmlFor="Name" className="font-bold text-left">Name:</label>
                                <input type="text" id="Name" className="border-[#1f2937]/20 border rounded-lg p-1 mt-2"/>
                            </div>
                            <div className="flex flex-col mt-1">
                                <label htmlFor="Message" className="font-bold text-left">Message:</label>
                                <textarea type="text" rows="3"  id="Message" className="border-[#1f2937]/20 border rounded-lg resize-none p-1 mt-2"  placeholder="Laat hier je idee achter"/>
                            </div>
                            <button type="submit" className="text-white hover:bg-[#3b56b8] shadow-md  bg-dark_blue mt-4 rounded-lg p-1 ">Verstuur</button>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
}

export default ContactSection;