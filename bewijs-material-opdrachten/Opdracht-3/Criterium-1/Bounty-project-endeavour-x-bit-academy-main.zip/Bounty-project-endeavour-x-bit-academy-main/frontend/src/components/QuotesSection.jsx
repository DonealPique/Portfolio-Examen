import React, { useState, useEffect } from "react";
import placeholderImage from "../assets/profile.svg";
import quoteSymbol from "../assets/QuoteSymbol.svg";

function QuoteSection() {
  const [quote, setQuote] = useState({
    text: "Een grappige quote over een collega op het Endeavour Beach event.",
    author: "Koen Paul",
    role: "Volleybal pro",
  });

  useEffect(() => {
    setQuote;
  }, []);

  return (
    <div className="relative flex flex-col items-start px-6 py-8 sm:px-10 sm:py-12 lg:px-16 lg:py-16 xl:ml-16">
      <img
        src={quoteSymbol}
        alt="Quote symbol"
        className="absolute -top-8 -left-0.5 sm:-top-4 md:- lg:-top-[-3px] lg:-left-[-30px] w-32 h-24 lg:w-32 lg:h-24 opacity-100 pointer-events-none"
      />
      <p className="relative text-3xl lg:text-4xl text-graydark font-light mb-4 lg:mb-6">
        {quote.text}
      </p>
      <div className="flex items-center">
        <img
          src={placeholderImage}
          alt="Placeholder"
          className="w-12 h-12 rounded-full flex-shrink-0 mr-4 lg:mr-6"
        />
        <div>
          <p className="text-graydark font-medium">{quote.author}</p>
          <p className="text-sm text-lightgrey">{quote.role}</p>
        </div>
      </div>
    </div>
  );
}

export default QuoteSection;
