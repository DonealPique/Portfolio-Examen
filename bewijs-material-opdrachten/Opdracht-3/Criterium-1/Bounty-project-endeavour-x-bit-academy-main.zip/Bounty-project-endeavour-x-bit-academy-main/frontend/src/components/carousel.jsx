import React, { useState, useEffect } from "react";

const Carousel = () => {
    const [currentSlide, setCurrentSlide] = useState(0);
    const images = [
        "/src/assets/placeHolderImage.png?t=1732523416875", // voorbeeld
        "https://t4.ftcdn.net/jpg/07/23/14/93/360_F_723149335_tA0Fo8zefrHzYlSgXRMYHmBQk7CuWrRd.jpg", // voorbeeld
        "https://images.unsplash.com/photo-1470329508532-be27fda94658?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8Mnx8fGVufDB8fHx8fA%3D%3D"
    ];

    useEffect(() => {
        const slideInterval = setInterval(() => {
            goToNextSlide();
        }, 3000);

        return () => clearInterval(slideInterval);
    }, []);

    const goToPreviousImage = () => {
        setCurrentSlide((prevSlide) => 
            prevSlide === 0 ? images.length - 1 : prevSlide -1
        );
    };

    const goToNextImage = () => {
        setCurrentSlide((prevSlide) => (prevSlide + 1) % images.length);
    }

    return (
        <div className="relative w-full container mx-auto py-4 sm:px-0 px-4" data-carousel="slide">
            <div className="relative overflow-hidden h-[40rem] rounded-lg flex justify-center">
                {images.map((src, index) => (
                    <div
                        key={index}
                        className={`ease-in-out duration-700 w-full h-full flex justify-center py-4 relative ${
                            index === currentSlide ? "block" : "hidden"
                        }`}
                        data-carousel-item
                    >
                        <button onClick={goToPreviousImage} className="absolute top-1/2 left-2 transform -translate-y-1/2 bg-gray p-2 rounded-full">
                            &#9664;
                        </button>
                        <img
                            className="object-cover object-center w-full"
                            src={src}
                            alt={`Slide ${index + 1}`}
                        />

                        <button onClick={goToNextImage} className="absolute top-1/2 right-2 transform -translate-y-1/2 bg-gray p-2 rounded-full">
                            &#9654;
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Carousel;
