import SmallCard from "./SmallCardRecent";
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function RecenteEvents(){
  const [events, setEvents] = useState([]);
  useEffect(() => {
      fetch('http://localhost:8000/old-events.php')
      .then((res) => res.json())
      .then((data) => {
          setEvents(data);
          console.log(data);
      });
}, []);
    return(
        <>
        <div className="max-w-full w-full p-4 mt-10">
        <h1 className="text-2xl pb-5 xl:ml-12 font-bold">Check onze laatste events</h1>
        <div className="overflow-auto  w-auto flex sm:gap-5 xl:ml-12 gap-32">
          {events.map((event) => (
            <SmallCard key={event.id} event={event}/> 
          ))}
        </div>
        <div className="lg:px-14 lg:hidden">
                <Link
                    to="/events-overview"
                    className="flex items-center text-dark_blue font-bold hover:underline"
                >
                    Bekijk alle events
                </Link>
            </div>
      </div>
        </>
    )
}

export default RecenteEvents