import React from "react";

export default function InterestingFacts() {
    return (
        <div className="flex w-[80vw] lg:mx-36 sm:mx-auto flex-col my-14 flex-wrap">
            <h1 className="text-2xl font-bold mx-5">Leuke Feitjes</h1>
            <div>
                <div className="flex mx-5 items-center">
                    <div className="flex flex-wrap flex-col w-[50vw]">
                        <h2 className="font-bold text-xl">16</h2>
                        <h3>collega’s in de zee gesprongen</h3>
                    </div>
                    <div className="flex flex-col w-[50vw]">
                        <h2 className="font-bold text-xl">2</h2>
                        <h3>winnende teams</h3>
                    </div>
                </div>
                <div className="flex flex-wrap mx-5 items-center">
                    <div className="flex flex-col w-[50vw]">
                        <h2 className="font-bold text-xl">240</h2>
                        <h3>plaatjes gedraaid</h3>
                    </div>
                    <div className="flex flex-wrap flex-col w-[50vw]">
                        <h2 className="font-bold text-xl">450</h2>
                        <h3>drankjes gedronken</h3>
                    </div>
                </div>
            </div>
        </div>
    )
}