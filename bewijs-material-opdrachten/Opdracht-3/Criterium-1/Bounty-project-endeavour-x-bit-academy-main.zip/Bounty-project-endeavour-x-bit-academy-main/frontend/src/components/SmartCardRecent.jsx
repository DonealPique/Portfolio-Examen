import placeHolderPic from '../assets/placeHolderImage.png'
function SmallCard() {
    return(
        <div className="h-[400px] w-full">
                    <a href="#">
                        <img src={placeHolderPic} alt="image ..." className="w-[300px] max-w-[400px] h-[200px] object-cover"/>
                    </a>
                    {/*De gegevens moeten uit de json file worden gehaald */}
                    <div className="mt-5">
                        <div className="flex  align-middle w-[300px] justify-between">
                            <a href="#">
                                <h4 className="font-bold">Endeavour Beach Party</h4>
                            </a>
                            <div className="flex w-[100px] justify-end space-x-3">
                                <div className='flex  items-center space-x-1'>
                                    <a href="#" className="flex items-center space-x-1"><p>2</p>
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fillRule="evenodd" clipRule="evenodd" d="M13.5062 2.00561C12.2114 2.06524 11.014 2.5976 10.1134 3.46344L10 3.577L9.88667 3.46284C8.9291 2.5432 7.63736 2 6.25 2C3.35051 2 1 4.35051 1 7.25C1 10.8478 3.87401 14.3505 9.47 17.848C9.79427 18.0507 10.2057 18.0507 10.53 17.848C16.126 14.3505 19 10.8478 19 7.25C19 4.35051 16.6495 2 13.75 2L13.5062 2.00561Z" fill="#1F2533"/>
                                        </svg>
                                    </a>
                                </div>
                                <div className="flex  items-center ">
                                    <a href="#" className="flex items-center space-x-1"> <p>2</p>
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fillRule="evenodd" clipRule="evenodd" d="M10 3C5.613 3 2 6.09685 2 10C2 13.9031 5.613 17 10 17L10.3488 16.9935C11.6233 16.9456 12.8475 16.6359 13.9373 16.0967L14.186 15.966L14.3816 16.0318L14.6758 16.138L15.0611 16.2853L15.5121 16.4649L16.3111 16.7948C16.408 16.8354 16.5076 16.8775 16.6099 16.9208C17.3983 17.2547 18.2144 16.5082 17.9518 15.6933L17.144 13.153L17.1997 13.0587C17.722 12.1173 18 11.0766 18 10C18 6.09685 14.387 3 10 3Z" fill="#1F2533"/>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div className="flex w-full 
                            justify-start text-slate-400
                            text-xs ">
                            <a href="#" className="underline mr-2">Feesten</a>
                            <p className="mr-10">19 juni</p>
                            <p>Zandvoort</p>
                        </div>
                    </div>
                </div>
    )
}

export default SmallCard