import React from "react";
import { useState } from "react";

function SearchBar({ setResults }) {
   const [input, setInput] = useState("");

   const fetchData = (value) => {
      fetch("http://localhost:8000/alle-events.php")
         .then((response) => response.json())
         .then((json) => {
            const results = json.filter((event) => {
               return value && event && event.name && event.name.toLowerCase().includes(value);
            });
            setResults(results);
         })
         .catch((error) => console.error("Error fetching data:", error));
   };

   const handleChange = (e) => {
      const value = e.target.value;
      setInput(value);
      fetchData(value);
   };

   return (
      <input
         placeholder="Search..."
         type="text"
         value={input}
         onChange={handleChange}
         className="border border-solid border-blue focus:border-orangebright focus:outline-none focus:ring-0 p-1 rounded-lg"
      />
   );
}

export default SearchBar;