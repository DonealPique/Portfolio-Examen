import { useState, useEffect, useRef } from "react";
import { Link } from 'react-router-dom';
import Searchbar from "./searchbar";
import SearchResultsList from "./SearchResults"
import EndeavourLogo from "../assets/logo.svg";
import SearchIcon from "../assets/Search.svg";
import HamburgerIcon from "../assets/hamburger-icon.svg";
import CloseIcon from "../assets/close-icon.svg";


const Navbar = () => {
   const [isOpen, setIsOpen] = useState(false);
   const [isSearchOpen, setIsSearchOpen] = useState(false);
   const searchRef = useRef(null);


   useEffect(() => {
      const handleClickOutside = (event) => {
         const isDesktop = window.innerWidth >= 640;
         if (isDesktop && searchRef.current && !searchRef.current.contains(event.target)) {
            setIsSearchOpen(false);
         }
      };
   
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
         document.removeEventListener("mousedown", handleClickOutside);
      };
   }, [searchRef, isSearchOpen]);
   
   const [results, setResults] = useState([]);

   return (
      <nav id="navbar" className="container mx-auto px-4 py-2 flex justify-between">
<Link to="/"> <img className="sm:w-1/8 w-20 lg:w-60" src={EndeavourLogo} alt="Endeavour Logo" /></Link>
         <div className="sm:hidden">
            <button
               onClick={() => {
                  setIsOpen(!isOpen);
               }}
            >
               <img src={HamburgerIcon} alt="Hamburger Icon" />
            </button>
         </div>
         <div className="hidden sm:ml-6  sm:block ml-auto" ref={searchRef}>
            <div className="flex items-center justify-between">
               <Link to="/events-overview" className="rounded-md px-3 py-2 text-sm font-medium hover:text-blue duration-200">
                  Events
               </Link>
               <a href="#" className="rounded-md px-3 py-2 text-sm font-medium hover:text-blue duration-200">
                  Contact
               </a>
               <button onClick={() => setIsSearchOpen(!isSearchOpen)}>
                  <img src={SearchIcon} alt="Search Icon" />
               </button>
               {isSearchOpen && (
                  <div className="ml-4 flex flex-col relative">
                     <Searchbar setResults={setResults} />
                     <SearchResultsList results={results}/>
                  </div>
               )}
            </div>
         </div>
         <div
            className={`sm:hidden fixed top-0 right-0 w-48 h-full shadow-lg shadow-blue z-50 p-4 bg-blue transform transition-transform duration-500 
            ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <button
               onClick={() => setIsOpen(false)}
               className="text-gray-500 hover:text-gray-900 focus:outline-none focus:text-gray-900 mb-4"
            >
               <img src={CloseIcon} alt="Close" />
            </button>
            <a href="#" className="block mb-4 text-sm font-medium hover:bg-blue-500 hover:text-white">
               Events
            </a>
            <a href="#" className="block mb-4 text-sm font-medium hover:bg-blue-500 hover:text-white">
               Contact
            </a>
            <button onClick={() => setIsSearchOpen(!isSearchOpen)}>
               <img src={SearchIcon} alt="Search Icon" />
            </button>
            {isSearchOpen && (
               <div className="flex flex-col relative">
                  <Searchbar setResults={setResults}/>
                  <SearchResultsList results={results}/>
               </div>
            )}
         </div>
      </nav>
   );
}

export default Navbar;
