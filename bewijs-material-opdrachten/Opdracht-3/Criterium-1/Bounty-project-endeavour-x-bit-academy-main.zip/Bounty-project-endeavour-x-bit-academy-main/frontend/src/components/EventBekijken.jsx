import React, { useState, useEffect } from "react";
import planning from '../assets/planning.svg';
import planningAdd from '../assets/planningAdd.svg';
import location from '../assets/location.svg';
import locationAdd from '../assets/locationAdd.svg';
import hart from '../assets/hart.svg';
import hartAdd from '../assets/hartAdd.svg';
import aanmeldingen from '../assets/aanmeldingen.svg';
import { Link, useParams } from "react-router-dom";
import Navbar from "./navbar";
import InterestingFacts from './InterestingFacts';
import TitelImgEvent from "./TitleAfbeelding";
import Carousel from "../components/carousel"
import TeamSection from "../components/TeamSection"
import ContactSection from "../components/ContactSection"
import Footer from "../components/Footer"
import GerelateerdeEvents from "./GerelateerdeEvents";

function Lorem({ children }) {
    return (
        <p className="text-lg">{children}</p>
    )
}

function Heading({ children }) {
    return (
        <h2 className="text-2xl my-5 text-left font-semibold">{children}</h2>
    )
}

export default function EventBekijken() {
    const { eventId } = useParams();
    const [events, setEvents] = useState([]);
    const [counter, setCounter] = useState(0);

    useEffect(() => {
        fetch('http://localhost:8000/alle-events.php')
            .then(response => response.json())
            .then(data => {
                setEvents(data);
            })
            .catch(error => {
                console.error('Error fetching events:', error);
            });
    }, []);

    const eventData = events.find(event => event.id === parseInt(eventId));

    useEffect(() => {
        if (eventData) {
            setCounter(eventData.likes);
        }
    }, [eventData]);

    const handleLike = () => {
        setCounter(counter + 1);
    };

    return (
        <>
            <Navbar />
            <TitelImgEvent />
            <div className="flex w-full justify-center">
                <div className=" container flex flex-row flex-wrap justify-between">
                    <div className="flex flex-col py-10">
                        <Heading>{eventData ? eventData.name : 'Loading...'}</Heading>
                        <Lorem>{eventData ? eventData.description : 'Loading...'}</Lorem>
                    </div>
                    <div className="flex mt-16">
                        <div className="border-solid border-2 rounded-3xl relative border-black h-[370px] w-[408px]">
                            <div className="flex m-6 w-[356.8px] align-middle justify-between px-10 relative">
                                <img src={planning} alt="Planning" />
                                <div className="flex flex-col">
                                    <p className="mr-14">{eventData ? eventData.date : 'Loading...'}</p>
                                </div>
                                <div className="w-[28.800px]"></div>
                                <img className="border-2 p-2 rounded-lg border-solid border-grey" src={planningAdd} alt="Added planning" />
                            </div>
                            <div className="flex m-6 w-[356.8px] align-middle justify-between px-10 relative">
                                <img src={location} alt="Location" />
                                <div className="flex flex-col">
                                    <p className="pr-16">{eventData ? eventData.location : 'Loading...'}</p>
                                </div>
                                <div className="w-[28.800px]"></div>
                                <Link to="https://www.google.nl/maps/place/Endeavour/@52.3867353,4.6402187,16z/data=!4m6!3m5!1s0x47c5ef6e32b344bb:0xf7b3a10d271d2de6!8m2!3d52.3867353!4d4.6427936!16s%2Fg%2F11cn3vvz5j?entry=ttu&g_ep=EgoyMDI0MTExOS4yIKXMDSoASAFQAw%3D%3D">
                                    <img className="border-2 p-2 rounded-lg border-solid border-grey" src={locationAdd} alt="Added Location" />
                                </Link>
                            </div>
                            <div className="flex m-6 w-[356.8px] align-middle px-10 justify-between relative">
                                <img src={hart} alt="Hart" />
                                <div className="flex flex-col">
                                    <p className="pr-16">{counter}</p>
                                </div>
                                <div className="w-[28.800px]"></div>
                                <img onClick={handleLike} className="border-2 p-2 rounded-lg border-solid border-grey" src={hartAdd} alt="Added planning" />
                            </div>
                            <div className="flex m-6 justify-between px-10 relative">
                                <img src={aanmeldingen} alt="Hart" />
                                <div className="flex flex-col">
                                    <p className="pr-16">{eventData ? eventData.aanmeldingen : 'Loading...'} Aanmeldingen</p>
                                </div>
                                <div className="w-[28.800px]"></div>
                            </div>
                            <div className="flex justify-center align-middle">
                                <Link to={`/event-bekijken/${eventId}/EmailForm`}><button className="bg-[#0073E5] text-white rounded px-4 h-[15] flex justify-center align-middle"> Aanmelden </button></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mx-auto sm:px-0 px-4">
                <Heading>Wat te verwachten</Heading>
                <div className="w-1/2">
                    <div className="flex flex-col sm:flex-row justify-between w-full">
                        <div className="w-full sm:w-1/2">
                            <Heading>4</Heading>
                            <small>speelvarianten</small>
                        </div>
                        <div className="w-full sm:w-1/2">
                            <Heading>8</Heading>
                            <small>samengestelde groepen</small>
                        </div>
                    </div>
                    <div className="flex flex-col sm:flex-row justify-between w-full">
                        <div className="w-1/2">
                            <Heading>3</Heading>
                            <small>resitend dj's</small>

                        </div>
                        <div className="w-1/2">
                            <Heading>Genoeg</Heading>
                            <small>Eten en drinken</small>
                        </div>
                    </div>
                </div>
                <div className="w-3/5">
                    <Heading>Sfeerimpressie van afgelopen events</Heading>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>
            </div>
            <Carousel></Carousel>
            <InterestingFacts />
            <GerelateerdeEvents></GerelateerdeEvents>
            <ContactSection></ContactSection>
            <TeamSection></TeamSection>
            <Footer></Footer>
        </>
    )
};
