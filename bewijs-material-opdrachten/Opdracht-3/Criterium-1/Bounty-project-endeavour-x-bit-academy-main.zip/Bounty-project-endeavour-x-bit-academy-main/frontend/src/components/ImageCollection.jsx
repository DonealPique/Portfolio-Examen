import React from "react";
import ImageCollect from '../assets/ImageCollect.svg'

export default function ImageCollection() {
    return (
        <>
            <div className="justify-center w-[100vw] items-center flex-wrap flex col">
                <div className="flex flex-row flex-wrap">
                    <img src={ImageCollect} alt="Images" className="px-10 py-5" />
                    <img src={ImageCollect} alt="Images" className="px-10 py-5" />
                </div>
                <div className="flex flex-row flex-wrap">
                    <img src={ImageCollect} className="px-10 py-5" alt="Images" />
                    <img src={ImageCollect} className="px-10 py-5" alt="Images" />
                </div>
            </div>
        </>
    )
}