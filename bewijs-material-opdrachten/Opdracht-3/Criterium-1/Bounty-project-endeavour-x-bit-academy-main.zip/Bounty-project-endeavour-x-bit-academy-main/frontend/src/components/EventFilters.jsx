import { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import leftArrow from '../assets/icons/left-check.png';
import rightArrow from '../assets/icons/right-check.png';
import searchIcon from '../assets/icons/search-icon.png';
import dropdownIcon from '../assets/icons/dropdown.png';
import calendarIcon from '../assets/icons/calendar.png';
import EventCard from './EventCard';

function EventFilters({ events, limit }) {
    const [filteredEvents, setFilteredEvents] = useState(events.slice(0, limit));
    const [searchTerm, setSearchTerm] = useState('');
    const [locationFilter, setLocationFilter] = useState('');
    const [typeFilter, setTypeFilter] = useState('');
    const [currentMonth, setCurrentMonth] = useState('');
    const [selectedDate, setSelectedDate] = useState('');
    const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);
    const datePickerRef = useRef(null);

    const allLocations = [...new Set(events.map(event => event.location))];

    const months = [
        { value: '', label: 'Selecteer een maand' },
        { value: '2024-01', label: 'January 2024' },
        { value: '2024-02', label: 'February 2024' },
        { value: '2024-03', label: 'March 2024' },
        { value: '2024-04', label: 'April 2024' },
        { value: '2024-05', label: 'May 2024' },
        { value: '2024-06', label: 'June 2024' },
        { value: '2024-07', label: 'July 2024' },
        { value: '2024-08', label: 'August 2024' },
        { value: '2024-09', label: 'September 2024' },
        { value: '2024-10', label: 'October 2024' },
        { value: '2024-11', label: 'November 2024' },
        { value: '2024-12', label: 'December 2024' },
    ];

    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (datePickerRef.current && !datePickerRef.current.contains(event.target)) {
                setIsDatePickerOpen(false);
            }
        };

        document.addEventListener('mousedown', handleOutsideClick);
        return () => {
            document.removeEventListener('mousedown', handleOutsideClick);
        };
    }, []);

    useEffect(() => {
        let filtered = [...events];

        if (searchTerm) {
            filtered = filtered.filter(event =>
                event.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                event.location.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        if (locationFilter) {
            filtered = filtered.filter(event => event.location === locationFilter);
        }

        if (typeFilter) {
            filtered = filtered.filter(event => event.type === typeFilter);
        }

        if (currentMonth) {
            filtered = filtered.filter(event => event.date.startsWith(currentMonth));
        }

        if (selectedDate) {
            filtered = filtered.filter(event => event.date === selectedDate);
        }

        setFilteredEvents(filtered.slice(0, limit));
    }, [searchTerm, locationFilter, typeFilter, currentMonth, events, selectedDate, limit]);

    const handlePrevMonth = () => {
        const currentIndex = months.findIndex(month => month.value === currentMonth);
        if (currentIndex > 0) {
            setCurrentMonth(months[currentIndex - 1].value);
        }
    };

    const handleNextMonth = () => {
        const currentIndex = months.findIndex(month => month.value === currentMonth);
        if (currentIndex < months.length - 1) {
            setCurrentMonth(months[currentIndex + 1].value);
        }
    };

    const toggleDatePicker = () => {
        setIsDatePickerOpen(!isDatePickerOpen);
    };

    return (
        <div className="max-w-full w-full p-4 overflow-x-hidden mt-10">
            <h1 className="text-2xl text-graydark font-bold mb-6 lg:ml-5 xl:ml-28">Alle Events</h1>

            <div className="flex flex-col md:flex-row gap-4 sm:gap-4 md:space-x-4 mb-6 lg:space-x-0 xl:space-x-0 lg:flex justify-center lg:mr-3">

                <div className="flex w-full md:w-auto relative" ref={datePickerRef}>
                    <button onClick={toggleDatePicker} className="text-white p-1 flex items-center border border-grey rounded-md w-10 h-9 pl-2 pt-0.5 mt-1 sm:w-10 sm:h-10 sm:pl-2.5 sm:pt-0.5 sm:mb-1 md:h-9 lg:mr-2 xl:mr-2">
                        <img src={calendarIcon} alt="Calendar" className="w-5 h-5 mr-2" />
                    </button>
                    {isDatePickerOpen && (
                        <input
                            type="date"
                            value={selectedDate}
                            onChange={(e) => setSelectedDate(e.target.value)}
                            className="absolute bottom-14 left-32 ml-2 sm:w-96 sm:mb-1 sm:ml-4 sm:pl-5 xl:ml-12 text-graydark p-2 border border-grey rounded-md z-10"
                            placeholder="Selecteer een datum"
                        />
                    )}
                    <div className="flex items-center border rounded-xl w-full md:w-auto md:h-10 border-grey overflow-hidden flex-grow ml-4 lg:w-64 xl:w-96">
                        <input
                            className="p-2 flex-grow placeholder:text-graydark focus:outline-none"
                            placeholder="Zoeken"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <img src={searchIcon} alt="Search" className="w-4 h-4 mr-4 pr-0.5 lg:mr-5" />
                    </div>
                </div>

                <div className="relative w-full md:w-auto">
                    <select
                        className="border rounded-xl border-grey p-2 appearance-none w-full lg:w-72 xl:w-96 text-graydark focus:outline-none truncate pr-10"
                        onChange={(e) => setTypeFilter(e.target.value)}
                        style={{ backgroundImage: `url(${dropdownIcon})`, backgroundPosition: 'right 0.7rem center', backgroundRepeat: 'no-repeat', backgroundSize: '20px' }}
                    >
                        <option value="">Alle soorten events</option>
                        <option value="previous">Eerdere Evenementen</option>
                        <option value="upcoming">Aankomende Evenementen</option>
                    </select>
                </div>

                <div className="relative w-full md:w-auto">
                    <select
                        className="p-2 appearance-none w-full md:w-52 border-grey border rounded-xl lg:w-[306px] xl:w-96 xl:ml-0 focus:outline-none pr-10 truncate"
                        onChange={(e) => setLocationFilter(e.target.value)}
                        style={{ backgroundImage: `url(${dropdownIcon})`, backgroundPosition: 'right 0.7rem center', backgroundRepeat: 'no-repeat', backgroundSize: '20px' }}
                    >
                        <option value="">Locatie</option>
                        {allLocations.map((location, index) => (
                            <option key={index} value={location}>
                                {location}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            <div className="flex items-center justify-between mb-6 lg:mx-4 lg:mr-8 xl:ml-28 xl:mr-32">
                <button onClick={handlePrevMonth} className="border border-grey rounded w-8 h-7 pl-2.5 pt-2 pr-2 flex justify">
                    <img src={leftArrow} alt="Previous" className="w-2 h-3" />
                </button>
                <span className="font-bold text-xl text-graydark">
                    {currentMonth
                        ? months.find(month => month.value === currentMonth)?.label
                        : 'Selecteer een maand'}
                </span>
                <button onClick={handleNextMonth} className="border border-grey rounded w-8 h-7 pl-3 pt-0 pr-2">
                    <img src={rightArrow} alt="Next" className="w-2 h-3" />
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:ml-3 lg:mx-11 xl:mx-5 xl:ml-28 lg:gap-16 xl:gap-10">
                {filteredEvents.length > 0 ? (
                    filteredEvents.map((event, index) => (
                        <EventCard key={index} event={event} />
                    ))
                ) : (
                    <p>Geen evenementen gevonden!</p>
                )}
            </div>
        </div>
    );
}

EventFilters.propTypes = {
    events: PropTypes.arrayOf(
        PropTypes.shape({
            name: PropTypes.string.isRequired,
            description: PropTypes.string.isRequired,
            location: PropTypes.string.isRequired,
            date: PropTypes.string.isRequired,
            type: PropTypes.string.isRequired,
        })
    ).isRequired,
    limit: PropTypes.number.isRequired,
};

export default EventFilters;
