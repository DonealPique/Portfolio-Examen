import { Link, useParams } from 'react-router-dom';
import placeHolderPic from '../assets/placeHolderImage.png';
import React, { useState, useEffect } from 'react';

function TitelImgEvent() {
    const { eventId } = useParams();
    const [events, setEvents] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8000/alle-events.php')
            .then(response => response.json())
            .then(data => {
                setEvents(data)
            })
            .catch(error => console.error('Error fetching events:', error));
    }, []);

    const eventData = events.find(event => event.id === parseInt(eventId));

    return(
        <>
            <div className='relative flex w-[100vw]'>
                <div className='absolute z-10 w-[100vw] h-full'>
                    {/*link terug naar de events page */}
                    <Link to='/events-overview' className='text-blue text-xl  absolute left-10 sm:left-32 sm:top-12 top-10 flex items-center gap-2'>  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" clipRule="evenodd" d="M11.2929 4.29289C11.6834 3.90237 12.3166 3.90237 12.7071 4.29289C13.0676 4.65338 13.0953 5.22061 12.7903 5.6129L12.7071 5.70711L8.415 10L12.7071 14.2929C13.0676 14.6534 13.0953 15.2206 12.7903 15.6129L12.7071 15.7071C12.3466 16.0676 11.7794 16.0953 11.3871 15.7903L11.2929 15.7071L6.29289 10.7071C5.93241 10.3466 5.90468 9.77939 6.2097 9.3871L6.29289 9.29289L11.2929 4.29289Z" fill="#00B4FF"/>
                    </svg>Alle events </Link>
                    {/*De gegevens moeten uit de json file worden gehaald edit: het is all gedaan door Nour*/}
                    <div className='absolute left-10 sm:left-32 bottom-14'>
                        <h4 className="font-bold sm:text-5xl text-3xl">{eventData ? eventData.name : 'Loading...'}</h4>
                        <div className="flex
                            justify-start text-[#6B7280]
                            text-base gap-6 mt-2">
                            {/* <a href="#" className="underline ">Feesten</a> */}
                            <p className="">{eventData ? eventData.date : 'Loading...'}</p>
                            <p>{eventData ? eventData.location : 'Loading...'}</p>
                        </div>
                    </div>
                </div>
                <img src={placeHolderPic} alt="event" className='w-full h-[600px]  z-0 object-cover'/>               
            </div>
        </>
    );
}

export default TitelImgEvent