import { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';

function EventStats() {
  const [stats, setStats] = useState({ upcoming: 0, past: 0, trips: 0, vrijmibos: "???" });
  const [isVisible, setIsVisible] = useState(false);
  const statsRef = useRef(null);

  useEffect(() => {
    fetch('http://localhost:8000/alle-events.php')
      .then(response => response.json())
      .then(data => {
        const upcoming = data.filter(event => event.type === 'upcoming').length;
        const past = data.filter(event => event.type === 'previous').length;
        const trips = data.filter(event => event.location && event.location.toLowerCase() !== 'office').length;
        
        const vrijmibos = data.some(event => event.name.toLowerCase().includes('vrijmibo'))
          ? data.filter(event => event.name.toLowerCase().includes('vrijmibo')).length
          : "???";

        setStats({ upcoming, past, trips, vrijmibos });
      })
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setIsVisible(entry.isIntersecting),
      { threshold: 0.5 }
    );
    const currentRef = statsRef.current;
    if (currentRef) observer.observe(currentRef);

    return () => {
      if (currentRef) observer.unobserve(currentRef);
    };
  }, []);

  return (
    <div ref={statsRef} className="p-10 bg-white">
      <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 sm:gap-10 lg:grid-cols-2 lg:mx-40 xl:mx-72 gap-8 text-center">
        {Object.entries(stats).map(([key, value], index) => (
          <StatCounter key={index} label={labels[key]} count={value} isVisible={isVisible} />
        ))}
      </div>
    </div>
  );
}

const labels = {
  upcoming: 'Aankomende events',
  past: 'Afgelopen events',
  trips: 'Trips in verschillende landen',
  vrijmibos: "Vrijmibo's"
};

function StatCounter({ label, count, isVisible }) {
  const [displayedCount, setDisplayedCount] = useState(0);

  useEffect(() => {
    if (isVisible && typeof count === "number") {
      const increment = Math.ceil(count / 50); 
      const interval = setInterval(() => {
        setDisplayedCount(prev => {
          if (prev + increment >= count) {
            clearInterval(interval);
            return count;
          }
          return prev + increment;
        });
      }, 200);
    } else if (count === "???") {
      setDisplayedCount("???");
    }
  }, [isVisible, count]);

  return (
    <div>
      <div className="text-4xl font-bold text-graydark">{displayedCount}</div>
      <div className="text-graydark mt-2">{label}</div>
    </div>
  );
}

StatCounter.propTypes = {
  label: PropTypes.string.isRequired,
  count: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
  isVisible: PropTypes.bool.isRequired,
};

export default EventStats;
// Done