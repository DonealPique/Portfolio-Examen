import React from "react";

export default function OnThisEvent() {
    return (
        <div className="flex flex-col lg:mx-36 ml-4 flex-wrap">
            <span className="font-bold mb-8">Op dit Event</span>
            <ul>
                <li className="mx-7 list-disc">Zijn vier verschillende spelvarianten gespeeld, namelijk:........</li>
                <li className="mx-7 list-disc">Nog iets dat gebeurd is op het event.</li>
                <li className="mx-7 list-disc">En nog een andere gebeurtenis.</li>
                <li className="mx-7 list-disc">Iets anders dat memorabel is.</li>
            </ul>
        </div>
    )
}