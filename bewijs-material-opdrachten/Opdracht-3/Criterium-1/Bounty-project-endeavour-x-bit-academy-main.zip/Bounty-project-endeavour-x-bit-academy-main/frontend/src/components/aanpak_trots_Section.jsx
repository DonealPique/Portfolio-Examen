function ApproachSection() {
    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <div className="mb-10">
                <h2 className="text-2xl font-bold text-graydark mb-8">Onze aanpak</h2>
                <p className="text-graydark mb-12">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 xl:gap-7">
                    <img src="https://placehold.co/600x400" alt="Placeholder image 1" className="w-full h-auto object-cover" />
                    <img src="https://placehold.co/600x400" alt="Placeholde image 2" className="w-full h-auto object-cover" />
                    <img src="https://placehold.co/600x400" alt="Placeholder image 3" className="w-full h-auto object-cover" />
                    <img src="https://placehold.co/600x400" alt="Placeholder image 4" className="w-full h-auto object-cover" />
                </div>
            </div>

            <div>
                <h2 className="text-2xl font-bold text-graydark mb-8 mt-12">Waar we trots op zijn</h2>
                <p className="text-graydark mb-8">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
            </div>
        </div>
    );
}

export default ApproachSection;
