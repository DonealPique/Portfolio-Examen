import React from "react";
import { Link } from "react-router-dom";

function SearchResultsList({ results = [] }) {
  return (
    <div className="w-full bg-white flex flex-col shadow-lg rounded mt-1 max-h-20 overflow-y-scroll absolute top-full left-0 px-1">
      {results.map((result, id) => (
        <Link
          to={`/events-bekijken/${result.id}`}
          key={id}
          className="block text-dark_blue font-bold hover:underline py-2"
        >
          {result.name}
        </Link>
      ))}
    </div>
  );
}

export default SearchResultsList;
