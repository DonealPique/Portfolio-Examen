function CultureSection() {
    return (
        <div className="bg-white py-10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 sm:pl-4 lg:px-8">
                <div className="flex flex-col md:flex-row items-center gap-8 md:mt-16 lg:mt-16 xl:mt-16">
                    <div className="flex-1">
                        <img
                            src="https://placehold.co/600x400"
                            alt="culture image"
                            className="w-full h-auto shadow-lg"
                        />
                    </div>
                    <div className="flex-1 space-y-4 md:ml-20">
                        <h2 className="text-2xl font-bold pb-4">Onze cultuur</h2>
                        <p className="pb-5">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                        <button
                            href="#"
                            type="button"
                            className="inline-block px-6 py-2 rounded border border-grey"
                        >
                            Lees meer
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CultureSection;
