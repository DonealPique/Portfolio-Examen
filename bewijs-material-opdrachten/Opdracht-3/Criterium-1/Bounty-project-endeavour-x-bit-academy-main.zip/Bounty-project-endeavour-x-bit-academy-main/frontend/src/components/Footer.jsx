import FigmaMailProfile from '../assets/profile.svg';
import FigmaPhone from '../assets/phone.svg';
import FigmaMail from '../assets/mail.svg';
import ArrowUp from '../assets/arrow_up.svg';
import Location from '../assets/location.svg';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

function Heading({ children }) {
    return (
        <h1 className="text-[18px] font-bold mb-4">{children}</h1>
    )
}

function Link2({ children }) {
    return (
        // URL apart toevoegen.
        <a className="flex gap-3 text-[18px] font-semibold">{children}</a>
    )
}

Heading.propTypes = {
    children: PropTypes.string.isRequired
}
Link2.propTypes = {
    children: PropTypes.string.isRequired
}

export default function Footer() {
    // Replace all links with the right page using href

    return (
        <footer className="flex-col flex align-middle border-solid container mx-auto px-4">
            <div className="flex justify-evenly flex-wrap ml-5 gap-20">
                <div className='flex flex-row gap-20'>
                    <div className="flex-col gap-4 mr-5 flex">
                        <Heading>Events</Heading>
                        <Link to="/events-overview">Alle events</Link>
                        <a href="#">Afgelopen events</a>
                    </div>
                    <div className="flex-col gap-4 flex">
                        <Heading>Cultuur</Heading>
                        <a href="#">Over Endeavour Events</a>
                        <a href="#">Onze basisprincipes</a>
                    </div>
                </div>
                <div className="flex-col flex">
                    <Heading>Stel hier je vragen</Heading>
                    <div className="flex flex-row mt-5">
                        <img width="64em" height="64em" className="mr-5" src={FigmaMailProfile} alt="Profile" />
                        <div className="flex flex-col gap-3">
                            <a href="#"><img src={FigmaPhone} alt="Phone" /> 020 12 34 555</a>
                            <a href="mailto:info@example.com"><img src={FigmaMail} alt="Mail" /> info@example.com</a>
                        </div>
                    </div>
                </div>
                <div className="flex-col flex">
                    <a className='flex gap-3 text-[18px] font-semibold' href="#navbar"><img className='' src={ArrowUp} alt="Arrow up" /></a>
                </div>
            </div>
        </footer>
    );
}