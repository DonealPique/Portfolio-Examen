import React, { useState, useRef, useEffect } from 'react';
import { useParams } from 'react-router-dom';

function EventDetail() {
    const { eventId } = useParams();
    const [events, setEvents] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8000/alle-events.php')
            .then(response => response.json())
            .then(data => {
                setEvents(data);
            })
            .catch(error => {
                console.error('Error fetching events:', error);
            });
    }, []);

    const eventData = events.find(event => event.id === parseInt(eventId));

    const videoRef = useRef(null);
    const [isPlaying, setIsPlaying] = useState(false);

    const togglePlayPause = () => {
        if (videoRef.current) {
            if (isPlaying) {
                videoRef.current.pause();
            } else {
                videoRef.current.play();
            }
            setIsPlaying(!isPlaying);
        }
    };

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className='flex flex-row w-[40vw] justify-between flex-wrap'>
                <div className='flex flex-col mb-20'>
                    <p className='text-grey text-lg'>Location</p>
                    <h1 className='text-3xl font-bold'>{eventData ? eventData.location : 'Loading...'}</h1>
                </div>
                <div className='flex flex-col'>
                    <p className='text-grey text-lg'>Date</p>
                    <h1 className='text-3xl font-bold'>{eventData ? eventData.date : 'Loading...'}</h1>
                </div>
            </div>
            <h2 className="text-2xl font-bold mb-10">Aftermovie</h2>

            <div className="relative bg-grey aspect-w-16 aspect-h-9">
                <video
                    ref={videoRef}
                    className="w-full h-full shadow-lg"
                    src="https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                    controls
                    poster="https://via.placeholder.com/800x450"
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                />

                <button
                    onClick={togglePlayPause}
                    className="absolute inset-0 flex items-center justify-center"
                    style={{ pointerEvents: 'none' }}
                >
                    <div className="bg-white border-grey shadow-lg border-2 rounded-full p-2 flex items-center justify-center">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            className="w-12 h-12 text-graydark"
                        >
                            <path
                                fill="currentColor"
                                d={isPlaying ? "M6 19h4V5H6v14zm8-14v14h4V5h-4z" : "M8 5v14l11-7z"}
                            />
                        </svg>
                    </div>
                </button>
            </div>

            <p className="text-sm text-lightgrey mt-2 block md:hidden">
                This is an optional caption for videos.
            </p>

            <div className="mt-16 mb-20">
                <h3 className="text-xl font-semibold text-graydark mb-10">Beschrijving van de dag</h3>
                <p className="text-graydark mt-4">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
            </div>

            <div className="mt-8">
                <h4 className="text-lg font-semibold">This is a heading 3</h4>
                <p className="text-graydark mt-10">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
                    dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <p className="text-graydark mt-8 mb-10">
                    Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum.
                    Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien
                    ut libero venenatis faucibus.
                </p>
            </div>
        </div>
    );
}

export default EventDetail;
