import placeHolderPic from '../assets/placeHolderImage.png';
import PropTypes from 'prop-types';

function SmallCard({ eventSmall }) {
    return (
        <div className="lg:w-100 h-60">
            <a href="#" className="block">
                <img
                    src={placeHolderPic}
                    alt={eventSmall.name}
                    className="w-full h-[300px] lg:h-[260px] object-cover shadow-lg"
                />
            </a>
            <div className="mt-5">
                <a href="#" className="block">
                    <h4 className="font-bold text-sm lg:text-lg">{eventSmall.name}</h4>
                </a>
                <div className="flex flex-wrap justify-start text-lightgrey text-xs mt-1">
                    <a href="#" className="underline mr-4">{eventSmall.type}</a>
                    <p className="mr-4">{eventSmall.date}</p>
                    <p>{eventSmall.location}</p>
                </div>
            </div>
        </div>
    );
}

SmallCard.propTypes = {
    eventSmall: PropTypes.shape({
        name: PropTypes.string.isRequired,
        type: PropTypes.string.isRequired,
        date: PropTypes.string.isRequired,
        location: PropTypes.string.isRequired,
    }).isRequired,
};

export default SmallCard;
