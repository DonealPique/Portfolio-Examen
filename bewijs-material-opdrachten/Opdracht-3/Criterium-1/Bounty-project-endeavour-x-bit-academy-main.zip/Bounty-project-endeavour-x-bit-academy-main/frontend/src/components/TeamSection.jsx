import PropTypes from 'prop-types';
import phoneIcon from '../assets/icons/blue-phone.png';
import mailIcon from '../assets/icons/blue-mail.png';
import profileIcon from '../assets/icons/Profile Image.png';

const teamMembers = [
  {
    name: 'Ralf Zonneveld',
    role: 'Event Organizer',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    phone: '06 12345678',
    email: 'name@example.com',
  },
  {
    name: 'Tim Schipper',
    role: 'Event Organizer',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    phone: '06 12345678',
    email: 'name@example.com',
  },
  {
    name: 'Duncan Borsboom',
    role: 'People Director',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    phone: '06 12345678',
    email: 'name@example.com',
  },
];

function TeamCard({ member }) {
  return (
    <div className="bg-white shadow-md rounded-lg p-6 text-center max-w-xs border border-grey">
      <img src={profileIcon} alt="Profile" className="w-24 h-24 mx-auto rounded-full mb-4" />
      <h3 className="text-lg font-semibold">{member.name}</h3>
      <p className="text-sm text-lightgrey mb-6">{member.role}</p>
      <p className="text-graydark text-sm my-3">{member.description}</p>
      <div className="text-dark_blue flex flex-col items-center">
        <div className="flex items-center space-x-2 mb-3">
          <img src={phoneIcon} alt="Phone" className="w-4 h-4" />
          <span>{member.phone}</span>
        </div>
        <div className="flex items-center space-x-2">
          <img src={mailIcon} alt="Mail" className="w-4 h-4" />
          <a href={`mailto:${member.email}`} className="text-dark_blue">{member.email}</a>
        </div>
      </div>
    </div>
  );
}

TeamCard.propTypes = {
  member: PropTypes.shape({
    name: PropTypes.string.isRequired,
    role: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    phone: PropTypes.string.isRequired,
    email: PropTypes.string.isRequired,
  }).isRequired,
};

function TeamSection() {
  return (
    <div className="py-10">
      <h2 className="text-2xl font-bold xl:ml-32 mb-8 ml-3">Het Endeavour event team</h2>
      <div className="flex overflow-x-auto space-x-6 xl:space-x-40 px-6 md:px-4 md:justify-center">
        {teamMembers.map((member, index) => (
          <TeamCard key={index} member={member} />
        ))}
      </div>
    </div>
  );
}

export default TeamSection;
