import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import arrowRight from '../assets/icons/arrow-right.png';

function EventCard({ event }) {
    const placeholderImage = 'https://placehold.co/600x400';

    return (

        <div className="bg-white md:rounded-xl md:shadow-lg overflow-hidden flex md:flex-col md:h-96 lg:w-72 lg:h-96 xl:w-80 w-full">
            <img
                src={placeholderImage}
                alt={event.name}
                className="w-20 h-20 md:w-full md:h-40 object-cover mt-10 sm:mt-10 md:mt-0"
            />

            <div className="p-4 flex flex-col justify-between flex-grow ml-4 md:ml-0 md:border-l md:border-r md:border-b md:rounded-b-xl md:border-grey">
                <div className="flex justify-between md:block">
                    <h1 className="text-lg font-bold flex-grow text-graydark">{event.name}</h1>
                </div>

                <p className="text-sm text-lightgrey mt-2 md:mt-1 flex gap-4">
                    <span className="underline">Feesten</span>
                    <span className="">{event.date}</span>
                    <span className=" md:overflow-hidden md:text-ellipsis md:whitespace-nowrap md:mr-10">{event.location}</span>
                </p>

                <p className="text-sm text-gray-700 lg:line-clamp-3 md:block hidden">{event.description}</p>

                <Link to={`/events-bekijken/${event.id}`} className="items-center text-dark_blue flex font-bold hover:underline md:flex mb-5">
                    Bekijk event <img src={arrowRight} alt="Arrow right" className="ml-2 mt-1 w-4 h-4" />
                </Link>
            </div>
        </div>
    );
}

EventCard.propTypes = {
    event: PropTypes.shape({
        name: PropTypes.string.isRequired,
        date: PropTypes.string.isRequired,
        location: PropTypes.string.isRequired,
        description: PropTypes.string.isRequired,
    }).isRequired,
};

export default EventCard;
