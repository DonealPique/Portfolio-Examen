import placeHolderPic from '../assets/placeHolderImage.png';
import SmallCard from './SmallCard';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function Cards() {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8000/upcomming-events.php')
            .then((res) => res.json())
            .then((data) => {
                setEvents(data);
            });
    }, []);

    return (
        <div className="w-full overflow-x-auto">
            <h1 className='text-3xl font-bold ml-4 lg:ml-14 mt-14'>Aankomende events</h1>
            <div className="flex lg:grid lg:grid-cols-3 gap-4 w-[1500px] lg:w-full px-4 lg:px-14 mt-8">

                <div className="lg:col-span-2 flex-shrink-0 lg:w-full h-full">
                    <div className="w-full h-full">
                        <img
                            src={placeHolderPic}
                            alt={events[0]?.name || "Placeholder"}
                            className="w-full h-[300px] lg:h-[600px] object-cover shadow-lg"
                        />
                        <div className="mt-5">
                            <a href="#" className="block">
                                <h4 className="font-bold text-lg lg:text-2xl">{events[0]?.name}</h4>
                            </a>
                            <div className="flex flex-wrap lg:justify-between justify-start text-xs lg:text-sm text-lightgrey mt-1 lg:mr-72 xl:mr-[570px]">
                                <a href="#" className="underline mr-4">{events[0]?.type}</a>
                                <p className="mr-4">{events[0]?.date}</p>
                                <p>{events[0]?.location}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex lg:col-span-1 flex-row lg:flex-col gap-4 lg:gap-24 w-full">
                    {events.slice(1, 3).map((eventSmall) => (
                        <SmallCard key={eventSmall.id} eventSmall={eventSmall} />
                    ))}
                </div>
            </div>

            <div className="px-4 lg:px-14 mt-8 mb-20">
                <Link
                    to={`/events-overview`}
                    className="flex items-center text-dark_blue font-bold hover:underline"
                >
                    Bekijk alle events
                </Link>
            </div>
        </div>
    );
}

export default Cards;
