import React from "react";
import { useState, useEffect } from 'react';
import EventFilters from '../components/EventFilters';
import CultureSection from '../components/CultureSection';
import Footer from '../components/Footer';
import Navbar from '../components/navbar';
import RecenteEvents from '../components/recenteEvents';
import AankomendeEventsSection from '../components/AankomendeEvents';
import ContactSection from '../components/ContactSection';
import EventStats from '../components/EventsCounter';
import TeamSection from '../components/TeamSection';

export default function Home() {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8000/alle-events.php')
            .then(response => response.json())
            .then(data => setEvents(data))
            .catch(error => console.error('Error fetching events:', error));
    }, []);

    return (
        <>
            <Navbar />
            <main>
                <AankomendeEventsSection />
                <RecenteEvents />
                <EventFilters events={events} limit={6} />
                <CultureSection />
                <EventStats />
                <ContactSection />
                <TeamSection />
            </main>

            <Footer />
        </>
    );
}