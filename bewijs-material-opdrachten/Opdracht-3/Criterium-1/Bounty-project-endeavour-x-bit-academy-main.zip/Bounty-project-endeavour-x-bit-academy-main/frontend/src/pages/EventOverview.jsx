import React from "react";
import { useState, useEffect } from 'react';
import EventFilters from '../components/EventFilters';
import Footer from '../components/Footer';
import Navbar from '../components/navbar';
import ContactSection from '../components/ContactSection';

export default function Home() {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8000/alle-events.php')
            .then(response => response.json())
            .then(data => setEvents(data))
            .catch(error => console.error('Error fetching events:', error));
    }, []);

    return (
        <>
            <Navbar />
            <main>
            <EventFilters events={events} limit={9} />
            <ContactSection />
            </main>
            <Footer />
        </>
    );
}