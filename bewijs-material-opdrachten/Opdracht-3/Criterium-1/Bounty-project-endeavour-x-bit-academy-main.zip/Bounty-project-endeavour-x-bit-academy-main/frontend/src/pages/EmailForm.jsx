import React from "react";

const EmailForm = () => {

    return (
        <div className="flex justify-center items-center w-[100vw]">
            <form className="border-solid border-2 border-black" onSubmit={localStorage.setItem('person', JSON.stringify())}>
                <input
                    type="email"
                    id="email"
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Emailadres"
                    required
                />
                <input
                    type="text"
                    id="name"
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Name"
                    required
                />
                <button type="submit">Send Email</button>
            </form>
        </div>
    );
};

export default EmailForm;