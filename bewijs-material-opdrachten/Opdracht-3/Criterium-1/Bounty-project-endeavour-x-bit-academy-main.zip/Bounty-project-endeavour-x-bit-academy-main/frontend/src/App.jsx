import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import EventsOverview from './pages/EventOverview';
import EventBekijken from './components/EventBekijken';
import EmailForm from './pages/EmailForm';
import PreviousEvent from './pages/PreviousEvent';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/events-overview" element={<EventsOverview />} />
                <Route path="/events-bekijken/:eventId" element={<EventBekijken />} />
                <Route path="/event-bekijken/:eventId/EmailForm" element={<EmailForm />} />
                <Route path="/previous-event/:eventId" element={<PreviousEvent />} />
            </Routes>
        </Router>
    );
}

export default App;
