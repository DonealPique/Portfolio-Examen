/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx}",
  ],
  theme: {
    colors: {
      blue: '#00B4FF',
      dark_blue: '#0073E5',
      pink: '#FF00FF',
      orangebright: '#FFB400',
      orangedark: '#FF7800',
      white: '#ffffff',
      gray: '#f3f4f6',
      graydark: '#1F2533',
      lightgrey: '#7A8599',
      grey: '#D3D7E0',
    },
    extend: {},
  },
  plugins: [
  ],
}