# Bounty project Endeavour x Bit Academy

Opdracht omschrijving in [google drive](https://drive.google.com/drive/folders/11ctFSB30VqUlGmFmHLEcPdGP6ZXR8vAT)

