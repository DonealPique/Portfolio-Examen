<?php
require 'database.php'; //Loads  the  database file

try {
    $pdo = createDatabase();
    $stmt = $pdo->prepare("SELECT * FROM events ORDER BY id ASC"); // Get all events and sort them by ID from ascending order
    
    $stmt->execute(); //  Run the command to get the events
    
    $alle_events = $stmt->fetchAll(PDO::FETCH_ASSOC); // Save the events in a list
} catch (\Throwable $th) {  // error 
    $alle_events = json_decode(file_get_contents('events.json'), true);
}

// allow cors
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');

// Give data in JSON format on the browser

header('Content-Type: application/json');
echo json_encode($alle_events);


