# Installation

You need Docker Engine to run the commands for setting up the database container.
This can be installed from the official website: 
<a href="https://docs.docker.com/engine/install/">https://docs.docker.com/engine/install/</a>

# Usage

### Use Bash, start in the database folder!

## Database

To start the database container we run the following command:

```sh
docker run -d --name database \
    -p 3306:3306 \
    -e MYSQL_ROOT_PASSWORD=endeavour \
    -e MYSQL_DATABASE=eventdbase \
    -e MYSQL_USER=bit_academy \
    -e MYSQL_PASSWORD=bit_academy \
    --mount type=bind,source=./Database.sql,destination=/docker-entrypoint-initdb.d/a.sql \
    mysql \
    --character-set-server=utf8mb4 \
    --collation-server=utf8mb4_unicode_ci
```

#### This command makes a container named `database` with the following settings:

- A admin user named `root` with password `endeavour`
- A normal user named `bit_academy` with password `bit_academy` <- this should be used in the application
- A database named 'eventdbase' where bit_academy has all the permissions
- A copy of the `Database.sql` file that is run when the container is created

## PHP My Admin

To start a container with phpmyadmin to check the database run the following command:

```sh
docker run --name phpmyadmin -d --link database:db -p 8082:80 phpmyadmin
```

#### This command makes a container named `phpmyadmin` with the following settings:

- Linked to the database running in the `database` container
- Accessible on port 8082 (<a href="http://localhost:8082">localhost:8082</a>)
- Login can be done with the database users, try `bit_academy`, `bit_academy`

### After starting, the containers will keep running until you manually stop them. They will remain in an 'exited' state until you explicitly remove them

To stop and remove the database container the following commands can be used:

```sh
docker stop database
docker rm database
```

To stop and remove the phpmyadmin container the following commands can be used:

```sh
docker stop phpmyadmin
docker rm phpmyadmin
```

## All in one command

To apply all these steps simultaniously, the following command combines the commands above. It can be run to stop and remove both containers and then start both up.

```sh
docker stop database phpmyadmin || true \
&& docker rm database phpmyadmin || true \
&& docker run -d --name database \
    -p 3306:3306 \
    -e MYSQL_ROOT_PASSWORD=endeavour \
    -e MYSQL_DATABASE=eventdbase \
    -e MYSQL_USER=bit_academy \
    -e MYSQL_PASSWORD=bit_academy \
    --mount type=bind,source=./Database.sql,destination=/docker-entrypoint-initdb.d/a.sql \
    mysql \
    --character-set-server=utf8mb4 \
    --collation-server=utf8mb4_unicode_ci \
&& docker run --name phpmyadmin -d --link database:db -p 8082:80 phpmyadmin
```

## Logs

If errors occur, check the logs with the following commands:

```sh
docker logs database
docker logs phpmyadmin
```

# Seeder

After starting the database you can run the seeder to fill the database with data.
```sh
php seeder.php
```