<?php
require 'database.php';

global $pdo;

// Haal quotes uit database en geef terug in JSON-formaat
$stmt = $pdo->prepare("SELECT * FROM quotes");
$stmt->execute();

$response = $stmt->fetchAll(PDO::PARAM_STR);

// allow cors
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');

header('Content-Type: application/json');

echo json_encode($response, JSON_PRETTY_PRINT);

?>
