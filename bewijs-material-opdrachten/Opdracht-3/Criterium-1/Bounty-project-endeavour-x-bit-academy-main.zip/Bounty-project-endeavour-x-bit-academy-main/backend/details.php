<?php
require 'database.php'; // Verbinding maken met database

try {
    $stmt = $pdo->prepare("
        SELECT 
            (SELECT COUNT(*) FROM events) AS total_events, -- Geeft totaal aantal evenementen
            (SELECT COUNT(*) FROM events WHERE type = 'upcoming') AS total_upcoming_events, -- Geeft totaal aantal aankomende evenementen
            (SELECT COUNT(*) FROM events WHERE type = 'previous') AS total_previous_events, -- Geeft totaal aantal vorige evenementen
            (SELECT SUM(likes) FROM events) AS total_likes, -- Totaal aantal likes op alle evenementen
            (SELECT COUNT(*) FROM comments) AS total_comments -- Totaal aantal comments op alle evenementen
    "); 

    $stmt->execute();

    // Haal de resultaten op als een associatieve array
    $totals = $stmt->fetch(PDO::FETCH_ASSOC);

    $response = [
        'totals' => $totals
    ];
} catch (\Throwable $th) {
    $response = [
        'error' => 'Error fetching total counts',
        'details' => $th->getMessage()
    ];
}

// Allow CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');
header('Content-Type: application/json');

// Zet de response in JSON-formaat en stuur het naar de browser
echo json_encode($response);
