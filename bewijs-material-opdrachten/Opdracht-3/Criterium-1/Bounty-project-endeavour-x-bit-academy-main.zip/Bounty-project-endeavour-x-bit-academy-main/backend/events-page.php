<?php

require 'database.php';

function getEventDetails($eventId)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = :id");
    $stmt->execute([':id' => $eventId]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        return null;
    }

    $stmtVideos = $pdo->prepare("SELECT * FROM event_videos WHERE event_id = :event_id");
    $stmtVideos->execute([':event_id' => $eventId]);
    $event['videos'] = $stmtVideos->fetchAll(PDO::FETCH_ASSOC);

    $stmtImages = $pdo->prepare("SELECT * FROM event_images WHERE event_id = :event_id");
    $stmtImages->execute([':event_id' => $eventId]);
    $event['images'] = $stmtImages->fetchAll(PDO::FETCH_ASSOC);

    $stmtComments = $pdo->prepare("SELECT * FROM comments WHERE eventid = :event_id");
    $stmtComments->execute([':event_id' => $eventId]);
    $event['comments'] = $stmtComments->fetchAll(PDO::FETCH_ASSOC);

    return $event;
}

// Allow CORS for all origins
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode([
        'error' => "No event ID provided. Call this endpoint with an id parameter: /events.php?id=<event_id>"
    ]);
    exit(1);
}

$eventId = (int)$_GET['id'];
$eventDetails = getEventDetails($eventId);

if ($eventDetails === null) {
    echo json_encode([
        'error' => "Event not found"
    ]);
    exit(1);
}

echo json_encode($eventDetails);

?>
