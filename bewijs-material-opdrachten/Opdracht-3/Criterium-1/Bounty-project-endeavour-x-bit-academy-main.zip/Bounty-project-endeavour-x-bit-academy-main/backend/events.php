<?php

// allow cors
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');

try {
    $data = json_decode(file_get_contents('data.json'), true);
    $event = $data;
    header('Content-Type: application/json');
    echo json_encode($event);
    exit();
} catch (\Throwable $th) {
    http_response_code(500);
    echo json_encode(['error' => $th->getCode(), 'msg' => $th->getMessage()]);
    exit(); 
}

?>