USE eventdbase;

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    location VARCHAR(255),
    description TEXT,
    type ENUM('upcoming', 'previous') NOT NULL,
    likes INT DEFAULT 0
);

CREATE TABLE comments (
    commentid INT AUTO_INCREMENT PRIMARY KEY,
    eventid INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    text TEXT NOT NULL,
    FOREIGN KEY (eventid) REFERENCES events(id) ON DELETE CASCADE
);

CREATE TABLE event_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    size ENUM('original', 'thumbnail') NOT NULL,
    path VARCHAR(255) NOT NULL,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

INSERT INTO event_images (id, event_id, size, path) VALUES
(1, 1, 'original', 'images/1-1-original.jpg'),
(2, 1, 'thumbnail', 'images/1-1-thumb.jpg');

CREATE TABLE event_videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    path VARCHAR(255) NOT NULL,
    type ENUM('highlight', 'full', 'other') DEFAULT 'highlight',
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

INSERT INTO event_videos (id, event_id, path, type) VALUES
(1, 1, 'videos/1-highlight.mp4', 'highlight'),
(2, 1, 'videos/1-full.mp4', 'full');


USE eventdbase;

CREATE TABLE IF NOT EXISTS quotes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_text TEXT NOT NULL
    ADD COLUMN author VARCHAR(255),
    ADD COLUMN role VARCHAR(255);
);

INSERT INTO quotes (quote_text, author, role) VALUES
('Je weet dat een event geslaagd is als de meeste gesprekken over de lunch gaan!', 'Anoniem', 'Eventmanager'),
('Ik ben niet te laat, ik ben precies op tijd voor de afterparty.', 'Anoniem', 'Partygoer'),
('Niets brengt een team zo samen als gratis koffie en wifi.', 'Anoniem', 'Kantoorhumorist'),
('Het echte hoogtepunt van dit event? De onverwachte dansmoves bij de borrel.', 'Anoniem', 'Dansliefhebber'),
('Netwerkborrels: waar je doet alsof je iemand kent, maar stiekem alleen voor de hapjes blijft.', 'Anoniem', 'Netwerker');
