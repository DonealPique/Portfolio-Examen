<?php
require 'database.php';

// Voeg een nieuw evenement toe
function addEvent($data) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO events (name, date, location, description, type) VALUES (:name, :date, :location, :description, :type)");
    return $stmt->execute($data) ? $pdo->lastInsertId() : false;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = array_map('trim', [
        ':name' => $_POST['name'] ?? '',
        ':date' => $_POST['date'] ?? '',
        ':location' => $_POST['location'] ?? '',
        ':description' => $_POST['description'] ?? '',
        ':type' => $_POST['type'] ?? ''
    ]);

    if (in_array('', $data)) {
        $message = "All fields are required!";
    } elseif ($id = addEvent($data)) {
        $message = "Event added successfully! Event ID: $id";
    } else {
        $message = "Failed to add the event.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Event</title>
</head>
<body>
    <h1>Add New Event</h1>
    <form method="POST">
        <label>Event Name: <input type="text" name="name" required></label>
        <label>Date: <input type="date" name="date" required></label>
        <label>Location: <input type="text" name="location" required></label>
        <label>Description: <textarea name="description" required></textarea></label>
        <label>Type: 
            <select name="type" required>
                <option value="upcoming">Upcoming</option>
                <option value="previous">Previous</option>
            </select>
        </label>
        <button type="submit">Add Event</button>
    </form>
    <!-- geef een bericht terug -->
    <?php if ($message): ?>
        <div class="<?php echo strpos($message, 'successfully') !== false ? 'success' : 'error'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
</body>
</html>
