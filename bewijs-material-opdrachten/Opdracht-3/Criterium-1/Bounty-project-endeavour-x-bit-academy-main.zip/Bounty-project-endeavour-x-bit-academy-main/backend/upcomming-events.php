<?php
require 'database.php';

global $pdo;

// Haal upcoming evenementen op en geef terug in JSON-formaat

$stmt = $pdo->prepare("SELECT * FROM events WHERE type = :type ORDER BY date ASC LIMIT 3");

$stmt->bindValue(':type', 'upcoming', PDO::PARAM_STR);

$stmt->execute();

$upcoming_events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// allow cors
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');

header('Content-Type: application/json');
echo json_encode($upcoming_events);

