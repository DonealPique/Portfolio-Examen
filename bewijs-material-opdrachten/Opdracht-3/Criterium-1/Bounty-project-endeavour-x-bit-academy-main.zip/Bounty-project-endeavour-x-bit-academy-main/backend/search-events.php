<?php

require 'database.php';

function searchEvents($query = '')
{
    global $pdo;

    // Zoek evenementen op basis van een zoekterm en geef terug in JSON-formaat
    $stmt = $pdo->prepare('SELECT * FROM events WHERE name LIKE :query');
    $stmt->execute([
        ':query' => "%$query%"
    ]);

    return $stmt->fetchAll();
}

// allow cors
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');

header('Content-Type: application/json');

// Controleer of een zoekterm is meegegeven in de queryparameters
if (!isset($_GET['query'])) {
    echo json_encode([
        'error' => "Geen query meegegeven. Roep dit endpoint aan met een query parameter: /search-events.php?query=<zoekterm>"
    ]);
    exit(1);
}
//Haal de evenementen op met de opgegeven zoekterm en geef ze terug in JSON-formaat
$events = searchEvents($_GET['query']);
echo json_encode($events);

