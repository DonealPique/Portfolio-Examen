<?php

require 'database.php';

function loadEvents($jsonFile)
{
    global $pdo;

    $jsonData = file_get_contents($jsonFile);
    $events = json_decode($jsonData, true);

    foreach ($events as $event) {
        $stmt_event = $pdo->prepare("INSERT INTO events (name, date, location, description, type, likes) VALUES (:name, :date, :location, :description, :type, :likes)");

        $stmt_event->execute([
            ':name' => $event['name'],
            ':date' => $event["date"],
            ':location' => $event['location'],
            ':description' => $event['description'],
            ':type' => $event['type'],
            ':likes' => isset($event['likes']) ? intval($event['likes']) : 0
        ]);


        $event_id = $pdo->lastInsertId();

        $stmt_comment = $pdo->prepare("INSERT INTO comments (eventid, name, text) VALUES (:eventid, :name, :text)");
        if (isset($event['comments'])) {
            foreach ($event['comments'] as $comment) {
                $stmt_comment->execute([
                    ':eventid' => $event_id,
                    ':name' => $comment['name'],
                    ':text' => $comment['text']
                ]);
            }
        }
    }
}

function clearEvents()
{
    global $pdo;

    $pdo->query('SET FOREIGN_KEY_CHECKS = 0');
    $stmt = $pdo->prepare('TRUNCATE table comments');
    if ($stmt->execute()) {
        echo "comments table truncated" . PHP_EOL;
    }
    $stmt = $pdo->prepare('TRUNCATE table events');
    if ($stmt->execute()) {
        echo "events table truncated" . PHP_EOL;
    }
    $pdo->query('SET FOREIGN_KEY_CHECKS = 1');
}

clearEvents();
loadEvents('events.json');
echo "Data loaded successfully!";
