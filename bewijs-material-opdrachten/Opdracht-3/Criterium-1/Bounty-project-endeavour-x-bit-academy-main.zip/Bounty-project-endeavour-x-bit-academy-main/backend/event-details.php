<?php

require 'database.php';  // Verbinding maken met database

function getEventDetails($eventId)
{
    global $pdo;

    // Haal evenement op basis van ID en controleer of het bestaat

    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = :id");
    $stmt->execute([':id' => $eventId]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        return null;
    }
    // Haal comments voor het evenement op
    $stmt = $pdo->prepare("SELECT * FROM comments WHERE eventid = :eventid");
    $stmt->execute([':eventid' => $eventId]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $event['comments'] = $comments;

    return $event;
}

// Allow CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');

header('Content-Type: application/json');

/// Controleer of een event ID is opgegeven.

if (!isset($_GET['id'])) {
    echo json_encode([
        'error' => "No event ID provided. Call this endpoint with an id parameter: /event-details.php?id=<event_id>"
    ]);
    exit(1);
}

$eventDetails = getEventDetails($_GET['id']);

//Haal de evenementdetails op met de opgegeven event ID. 
if ($eventDetails === null) {
    echo json_encode([
        'error' => "Event not found"
    ]);
    exit(1);
}

//geef terug in JSON-formaat
echo json_encode($eventDetails);
