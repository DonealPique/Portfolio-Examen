# Backend

Deze backend bied een API aan voor het Endeavour project. De aangeboden API kan gebruikt worden door de frontend.

## Installatie

Deze API draait door middel van plain PHP.  
Als database wordt een mysql database gebruikt.

Installeer PHP.  
TODO uitleg voor database.

Import `Database.sql` in uw MySQL-database.

## Gebruik

Voor testen is het eenvoudigste gebruik de build-in php development server.  
Navigeer naar de backend map.  
Run `php -S localhost:8000` (port kan je zelf kiezen, hier is 8000 als default genomen).

## API

De beschikbare API routes zijn momenteel:

- `localhost:8000/alle-events.php`: geeft alle events.

- `localhost:8000/search-events.php?query=<zoekterm>`: zoek events op <zoekterm>

- `localhost:8000/old-events.php`:geeft 3 previous events in json.

- `localhost:8000/upcomming-events.php`:geeft 3 upcoming events in json.

- `localhost:8000/events-page.php?id=<event_id>`:voor upcoming/previous events pagina. In de Database.sql-bestand staan twee SQL-tabellen: event_images en event_videos. Maak die ook aan in phpMyAdmin.

- `localhost:8000/new-events.php>`: Add new events to SQL JSON.

- `localhost:8000/details.php`:Totale aantallen evenementen, likes , comments, upcoming en previous events.

- `http://localhost:8000/event-quotes.php`: geef quotes in json.
In de Database.sql-bestand staan quotes sql tabel:Maak die ook aan in phpMyAdmin.